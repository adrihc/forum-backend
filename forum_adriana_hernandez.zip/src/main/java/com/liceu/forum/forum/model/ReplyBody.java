package com.liceu.forum.forum.model;

public class ReplyBody {
    String content;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
